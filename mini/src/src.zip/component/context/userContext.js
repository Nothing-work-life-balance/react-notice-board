import { createContext } from "react";

const userContext = createContext(null);

export default userContext;